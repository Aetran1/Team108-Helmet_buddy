/* 
 * File:   Lights.h
 * Author: kccun
 *
 * Created on April 27, 2022, 10:44 AM
 */

#ifndef LIGHTS_H
#define	LIGHTS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* LIGHTS_H */

