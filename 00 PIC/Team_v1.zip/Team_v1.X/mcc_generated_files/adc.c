/**
  ADC Generated Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    adc.c

  @Summary
    This is the generated driver implementation file for the ADC driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This source file provides implementations for driver APIs for ADC.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16LF1566
        Driver Version    :  2.02
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.31 and above
        MPLAB             :  MPLAB X 5.45
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

/**
  Section: Included Files
*/

#include <xc.h>
#include "adc.h"
#include "device_config.h"

void (*ADC1_InterruptHandler)(void);
void (*ADC2_InterruptHandler)(void);

/**
  Section: ADC Module APIs
*/

void ADC_Initialize(void)
{
    
    // GO_nDONE_ALL Completed; ADFM left; ADNREF VSS; ADPREF VDD; ADCS FOSC/4; 
    ADCON1 = 0x40;
    
    // TRIGSEL no_auto_trigger; 
    AAD1CON2 = 0x00;
    
    // TRIGSEL no_auto_trigger; 
    AAD2CON2 = 0x00;
    
    // ADRESL 0; 
    AAD1RES0L = 0x00;
    
    // ADRESH 0; 
    AAD1RES0H = 0x00;
    
    // ADRESL 0; 
    AAD2RES0L = 0x00;
    
    // ADRESH 0; 
    AAD2RES0H = 0x00;
    
    // ADRESL 0; 
    AAD1RES1L = 0x00;
    
    // ADRESH 0; 
    AAD1RES1H = 0x00;
    
    // ADRESL 0; 
    AAD2RES1L = 0x00;
    
    // ADRESH 0; 
    AAD2RES1H = 0x00;
    
    // CH19 Not connected to ADC1; CH18 Not connected to ADC1; 
    AD1CH1 = 0x00;
    
    // AD1DSEN Single conversion; AD1IPEN Non inverted; AD1IPPOL VREF-; AD1EPPOL Vss; 
    AAD1CON3 = 0x00;
    
    // AD2IPEN Non inverted; AD2DSEN Single conversion; AD2IPPOL VREF-; AD2EPPOL Vss; 
    AAD2CON3 = 0x00;
    
    // CH29 Not connected to ADC2; CH28 Not connected to ADC2; CH40 Not connected to ADC2; 
    AD2CH1 = 0x00;
    
    // GRD1BOE No Guard ring enabled; GRD1AOE No Guard ring enabled; GRD1POL Low; 
    AAD1GRD = 0x00;
    
    // GRD2BOE No Guard ring enabled; GRD2AOE No Guard ring enabled; GRD2POL Low; 
    AAD2GRD = 0x00;
    
    // A1TX1 disabled; A1TX2 disabled; A1TX0 disabled; 
    ADCTX = 0x00;
    
    // TX14 disabled; TX13 disabled; TX12 disabled; TX11 disabled; TX10 disabled; TX17 disabled; TX16 disabled; TX15 disabled; 
    AD1TX0 = 0x00;
    
    // TX19 disabled; TX18 disabled; 
    AD1TX1 = 0x00;
    
    // TX25 disabled; TX24 disabled; TX23 disabled; TX22 disabled; TX21 disabled; TX20 disabled; TX27 disabled; TX26 disabled; 
    AD2TX0 = 0x00;
    
    // TX40 disabled; TX29 disabled; TX28 disabled; 
    AD2TX1 = 0x00;
    
    // ADD1CAP Additional uC disabled; 
    AAD1CAP = 0x00;
    
    // ADD2CAP Additional uC disabled; 
    AAD2CAP = 0x00;
    
    // ADPRE 0; 
    AD1PRE = 0x00;
    
    // ADACQ 0; 
    AD1ACQ = 0x00;
    
    // ADPRE 0; 
    AD2PRE = 0x00;
    
    // ADACQ 0; 
    AD2ACQ = 0x00;
    
    // GO_nDONE1 stop; CHS AN0; ADON enabled; 
    AD1CON0 = 0x01;
    
    // GO_nDONE2 stop; CHS AN0; ADON disabled; 
    AD2CON0 = 0x00;
  

    


}

void ADC1_StartConversion(adc1_channel_t channel)
{
    // select the A/D channel
   AD1CON0bits.CHS = channel;

    // Turn on the ADC1 module
    AD1CON0bits.ADON= 1;

    // Start the conversion
    AD1CON0bits.GO_nDONE1 = 1;
}

void ADC2_StartConversion(adc2_channel_t channel)
{
    // select the A/D channel
   AD2CON0bits.CHS = channel;

    // Turn on the ADC2 module
    AD2CON0bits.ADON= 1;

    // Start the conversion
    AD2CON0bits.GO_nDONE2 = 1;
}

void ADC_StartSyncConversion(adc1_channel_t channelADC1, adc2_channel_t channelADC2)
{
    // select the A/D channel on ADC1
    AD1CON0bits.CHS = channelADC1;
    // select the A/D channel on ADC2
    AD2CON0bits.CHS = channelADC2;

    // Turn on the ADC1 module
    AD1CON0bits.ADON = 1;
    // Turn on the ADC2 module
    AD2CON0bits.ADON = 1;

    // Start the synchronized conversion
    ADCON1bits.GO_nDONE_ALL = 1;
}

bool ADC1_IsConversionDone(void)
{
    // Check conversion status
    return ((unsigned char)(!AD1CON0bits.GO_nDONE1));
}

bool ADC2_IsConversionDone(void)
{
    // Check conversion status
    return ((unsigned char)(!AD2CON0bits.GO_nDONE2));
}


bool ADC_IsSyncConversionDone(void)
{
    // Check conversion status
    return ((unsigned char)(!ADCON1bits.GO_nDONE_ALL));
}

adc_result_t ADC1_GetConversionResult(void)
{
    // Conversion finished, return the result
    return ((adc_result_t)((AAD1RES0H << 8) + AAD1RES0L));
}
adc_result_t ADC2_GetConversionResult(void)
{
    // Conversion finished, return the result
    return ((adc_result_t)((AAD2RES0H << 8) + AAD2RES0L));
}

adc_sync_result_t ADC_GetSyncConversionResult(void)
{
    adc_sync_result_t adcSyncResult;
  
    // Conversion finished, read the result
    adcSyncResult.adc1Result = (AAD1RES0H << 8) + AAD1RES0L;
    adcSyncResult.adc2Result = (AAD2RES0H << 8) + AAD2RES0L;

    // return the result
    return adcSyncResult;
}

adc_result_t ADC1_GetConversion(adc1_channel_t channel)
{
    // Select the A/D channel
     AD1CON0bits.CHS = channel;

    // Turn on the ADC1 module
    AD1CON0bits.ADON = 1;

    // Start the conversion
    AD1CON0bits.GO_nDONE1 = 1;

    // Wait for the conversion to finish
    while (AD1CON0bits.GO_nDONE1)
    {
    }
    
    // Conversion finished, return the result
    return ((adc_result_t)((AAD1RES0H << 8) + AAD1RES0L));
}

adc_result_t ADC2_GetConversion(adc2_channel_t channel)
{
    // Select the A/D channel
    AD2CON0bits.CHS = channel;

    // Turn on the ADC2 module
    AD2CON0bits.ADON = 1;

    // Start the conversion
    AD2CON0bits.GO_nDONE2 = 1;

    // Wait for the conversion to finish
    while (AD2CON0bits.GO_nDONE2)
    {
    }
    
    // Conversion finished, return the result
    return ((adc_result_t)((AAD2RES0H << 8) + AAD2RES0L));
}


adc_sync_result_t ADC_GetSyncConversion(adc1_channel_t adc1Channel, adc2_channel_t adc2Channel)
{
    adc_sync_result_t adcSyncResult;

    // Select the ADC1 channel
    AD1CON0bits.CHS = adc1Channel;

    // Select the ADC2 channel
    AD2CON0bits.CHS = adc2Channel;

    // Turn on the ADC1 module
    AD1CON0bits.ADON= 1;

    // Turn on the ADC2 module
    AD2CON0bits.ADON = 1;

    // Start the synchronized conversion
    ADCON1bits.GO_nDONE_ALL = 1;

    // Wait for the conversion to finish
    while (ADCON1bits.GO_nDONE_ALL)
    {
    }
    
    // Conversion finished, read the result
    adcSyncResult.adc1Result = (AAD1RES0H << 8) + AAD1RES0L;
    adcSyncResult.adc2Result = (AAD2RES0H << 8) + AAD2RES0L;

    // return the result
    return adcSyncResult;
}
void ADC_TemperatureAcquisitionDelay(void)
{
    __delay_us(200);
}

void ADC1_EnableDoubleSampling(void)
{
    //Sets the AAD1CON3bits.AD1DSEN
    AAD1CON3bits.AD1DSEN = 1;
}

void ADC2_EnableDoubleSampling(void)
{
    //Sets the AAD2CON3bits.AD2DSEN
    AAD2CON3bits.AD2DSEN = 1;
}

adc1_sync_double_result_t ADC1_GetDoubleConversionResult(void)
{
    adc1_sync_double_result_t adc1DoubleResult;

    // Conversion finished, read the result
    adc1DoubleResult.adc1Result1 = (AAD1RES0H << 8) + AAD1RES0L;
    adc1DoubleResult.adc1Result2 = (AAD1RES1H << 8) + AAD1RES1L;

    // return the result
    return adc1DoubleResult;
}

adc2_sync_double_result_t ADC2_GetDoubleConversionResult(void)
{
    adc2_sync_double_result_t adc2DoubleResult;

    // Conversion finished, read the result
    adc2DoubleResult.adc2Result1 = (AAD2RES0H << 8) + AAD2RES0L;
    adc2DoubleResult.adc2Result2 = (AAD2RES1H << 8) + AAD2RES1L;

    // return the result
    return adc2DoubleResult;
}

uint8_t ADC1_GetStageStatus(void)
{
	//Returns the contents of AADSTATbits.AD1STG field.
	return AADSTATbits.AD1STG;
}

uint8_t ADC2_GetStageStatus(void)
{
	//Returns the contents of AADSTATbits.AD2STG field.
	return AADSTATbits.AD2STG;
}

uint8_t ADC1_GetConversionStatus(void)
{
	//Returns the contents of AADSTATbits.AD1CONV field.
	return AADSTATbits.AD1CONV;
}

uint8_t ADC2_GetConversionStatus(void)
{
	//Returns the contents of AADSTATbits.AD2CONV field.
	return AADSTATbits.AD2CONV;
}

void ADC1_SetPrechargeTime(uint8_t prechargeTime)
{
	//Load the AD1PRE register.
	AD1PRE = prechargeTime;  
}

void ADC2_SetPrechargeTime(uint8_t prechargeTime)
{
	//Load the AD2PRE register.
	AD2PRE = prechargeTime;  
}

void ADC1_SetAcquisitionTime(uint8_t acquisitionValue)
{
	//Load the AD1ACQ register.
	AD1ACQ = acquisitionValue;   
}

void ADC2_SetAcquisitionTime(uint8_t acquisitionValue)
{
	//Load the AD2ACQ register.
	AD2ACQ = acquisitionValue;   
}



/**
 End of File
*/