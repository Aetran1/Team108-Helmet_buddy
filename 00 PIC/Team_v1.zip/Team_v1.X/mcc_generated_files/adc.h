/**
  ADC Generated Driver API Header File

  @Company
    Microchip Technology Inc.

  @File Name
    adc.h

  @Summary
    This is the generated header file for the ADC driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for ADC.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16LF1566
        Driver Version    :  2.02
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.31 and above
        MPLAB             :  MPLAB X 5.45
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef ADC_H
#define ADC_H

/**
  Section: Included Files
*/

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus  // Provide C++ Compatibility

    extern "C" {

#endif

/**
  Section: Data Types Definitions
*/

/**
 *  result size of an A/D conversion
 */
typedef uint16_t adc_result_t;

/**
 *  result type of a synchronized A/D conversion
 */
typedef struct
{
    adc_result_t adc1Result;
    adc_result_t adc2Result;
} adc_sync_result_t;

/**
 *  result type of a Double ADC1 conversion
 */
typedef struct
{
    adc_result_t adc1Result1;
    adc_result_t adc1Result2;
} adc1_sync_double_result_t;

/**
 *  result type of a Double ADC2 conversion
 */
typedef struct
{
    adc_result_t adc2Result1;
    adc_result_t adc2Result2;
} adc2_sync_double_result_t;

/** ADC1 Channel Definition

 @Summary
   Defines the ADC1 channels available for conversion.

 @Description
   This routine defines the channels that are available for the ADC1 module to use.

 Remarks:
   None
 */

typedef enum
{
    channel_FVR_adc1 =  0x3f,
    channel_VREFH_adc1 =  0x3b,
    channel_Temp_adc1 =  0x3d
} adc1_channel_t;

/** ADC2 Channel Definition

 @Summary
   Defines the ADC2 channels available for conversion.
     
 @Description
   This routine defines the channels that are available for the ADC2 module to use.

 Remarks:
   None
 */
typedef enum
{
    channel_FVR_adc2 =  0x2f,
    channel_VREFH_adc2 =  0x2b,
    channel_Temp_adc2 =  0x2d
} adc2_channel_t;



/**
  Section: ADC Module APIs
*/

/**
  @Summary
    Initializes the ADC

  @Description
    This routine initializes the Initializes the ADC.
    This routine must be called before any other ADC routine is called.
    This routine should only be called once during system initialization.

  @Preconditions
    None

  @Param
    None

  @Returns
    None

  @Comment
    

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();
    convertedValue = ADC_GetConversionResult();
    </code>
*/
void ADC_Initialize(void);

/**
  @Summary
    Allows selection of an ADC1 channel for conversion 

  @Description
    This routine is used to select desired channel for conversion.

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    None

  @Param
    Pass in required channel number
    "For available channel refer to enum under adc.h file"

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();
    ADC1_StartConversion(AN1_Channel);
    convertedValue = ADC1_GetConversionResult();
    </code>
*/
void ADC1_StartConversion(adc1_channel_t channel);

/**
  @Summary
    Allows selection of an ADC2 channel for conversion 

  @Description
    This routine is used to select desired channel for conversion.

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    None

  @Param
    Pass in required channel number
    "For available channel refer to enum under adc.h file"

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();
    ADC2_StartConversion(AN1_Channel);
    convertedValue = ADC2_GetConversionResult();
    </code>
*/
void ADC2_StartConversion(adc2_channel_t channel);

/**
  @Summary
    Allows selection of two channels for a synchronized conversion 

  @Description
    This routine is used to select the desired channels for a synchronized conversion.

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    None

  @Param
    Pass in required channel numbers
    "For available channels refer to the ADC1 and ADC2 enums under adc.h file"

  @Example
    <code>
    adc_sync_result_t convertedValues;

    ADC_Initialize();
    ADC_StartSyncConversion(AN1_Channel, AN2_Channel);
    convertedValues = ADC_GetSyncConversionResult();
    </code>
*/
void ADC_StartSyncConversion(adc1_channel_t channelADC1, adc2_channel_t channelADC2);

/**
  @Summary
    Returns true when the ADC1 conversion is completed otherwise false.

  @Description
    This routine is used to determine if an ADC1 conversion is completed.
    When conversion is complete routine returns true. It returns false otherwise.

  @Preconditions
    ADC_Initialize() and ADC1_StartConversion(adc1_channel_t channel)
    function should have been called before calling this function.

  @Returns
    true  - If conversion is complete
    false - If conversion is not completed

  @Param
    None

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();
    ADC1_StartConversion(AN1_Channel);

    while(!ADC1_IsConversionDone());
    convertedValue = ADC1_GetConversionResult();
    </code>
 */
bool ADC1_IsConversionDone(void);

/**
  @Summary
    Returns true when the ADC2 conversion is completed otherwise false.

  @Description
    This routine is used to determine if an ADC2 conversion is completed.
    When conversion is complete routine returns true. It returns false otherwise.

  @Preconditions
    ADC_Initialize() and ADC2_StartConversion(adc2_channel_t channel)
    function should have been called before calling this function.

  @Returns
    true  - If conversion is complete
    false - If conversion is not completed

  @Param
    None

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();
    ADC2_StartConversion(AN1_Channel);

    while(!ADC2_IsConversionDone());
    convertedValue = ADC2_GetConversionResult();
    </code>
 */
bool ADC2_IsConversionDone(void);

/**
  @Summary
    Returns true when a synchronized conversion is completed otherwise false.

  @Description
    This routine is used to determine if a synchronized conversion is completed.
    When conversion is complete routine returns true. It returns false otherwise.

  @Preconditions
    ADC_Initialize() and ADC_StartSyncConversion(adc1_channel_t channel1, adc2_channel_t channel2)
    function should have been called before calling this function.

  @Returns
    true  - If conversion is complete
    false - If conversion is not completed

  @Param
    None

  @Example
    <code>
    adc_sync_result_t convertedValues;

    ADC_Initialize();
    ADC_StartSyncConversion(AN1_Channel, AN2_channel);

    while(!ADC_IsSyncConversionDone());
    convertedValues = ADC_GetSyncConversionResult();
    </code>
 */
bool ADC_IsSyncConversionDone(void);

/**
  @Summary
    Returns the ADC1 conversion value.

  @Description
    This routine is used to get the analog to digital converted value. This
    routine gets converted values from the ADC1 channel specified.

  @Preconditions
    This routine returns the conversion value only after the conversion is complete.
    Completion status can be checked using the
    ADC1_IsConversionDone() routine.

  @Returns
    Returns the converted value.

  @Param
    None

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();
    ADC1_StartConversion(AN1_Channel);

    while(ADC1_IsConversionDone());

    convertedValue = ADC1_GetConversionResult();
    </code>
 */
adc_result_t ADC1_GetConversionResult(void);

/**
  @Summary
    Returns the ADC2 conversion value.

  @Description
    This routine is used to get the analog to digital converted value. This
    routine gets converted values from the ADC2 channel specified.

  @Preconditions
    This routine returns the conversion value only after the conversion is complete.
    Completion status can be checked using the
    ADC2_IsConversionDone() routine.

  @Returns
    Returns the converted value.

  @Param
    None

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();
    ADC2_StartConversion(AN1_Channel);

    while(ADC2_IsConversionDone());

    convertedValue = ADC2_GetConversionResult();
    </code>
 */
adc_result_t ADC2_GetConversionResult(void);

/**
  @Summary
    Returns the ADC synchronized conversion value.

  @Description
    This routine is used to get the analog to digital converted value. This
    routine gets converted values from the specified ADC1 and ADC2 channels.

  @Preconditions
    This routine returns the conversion value only after the conversion is complete.
    Completion status can be checked using the
    ADC_IsSyncConversionDone() routine.

  @Returns
    Returns the converted values.

  @Param
    None

  @Example
    <code>
    adc_sync_result_t convertedValues;

    ADC_Initialize();
    ADC_StartSyncConversion(AN1_Channel, AN2_Channel);

    while(ADC_IsSyncConversionDone());

    convertedValues = ADC_GetSyncConversionResult();
    </code>
 */
adc_sync_result_t ADC_GetSyncConversionResult(void);

/**
  @Summary
    Returns the ADC1 conversion value
    also allows selection of a channel for conversion.

  @Description
    This routine is used to select desired channel for conversion
    and to get the analog to digital converted value.

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    Returns the converted value.

  @Param
    Pass in required channel number.
    "For available channel refer to enum under adc.h file"

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();

    conversion = ADC1_GetConversion(AN1_Channel);
    </code>
*/
adc_result_t ADC1_GetConversion(adc1_channel_t channel);

/**
  @Summary
    Returns the ADC2 conversion value
    also allows selection of a channel for conversion.

  @Description
    This routine is used to select desired channel for conversion
    and to get the analog to digital converted value.

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    Returns the converted value.

  @Param
    Pass in required channel number.
    "For available channel refer to enum under adc.h file"

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();

    conversion = ADC2_GetConversion(AN1_Channel);
    </code>
*/
adc_result_t ADC2_GetConversion(adc2_channel_t channel);

/**
  @Summary
    Returns the ADC synchronized conversion value
    also allows selection of two channels for conversion.

  @Description
    This routine is used to select the desired channels for a synchronized conversion
    and to get the analog to digital converted values.

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    Returns the converted values.

  @Param
    Pass in required channel numbers.
    "For available channels refer to the ADC1 and ADC2 enums under adc.h file"

  @Example
    <code>
    adc_sync_result_t convertedValues;

    ADC_Initialize();

    conversion = ADC_GetSyncConversion(AN1_Channel, AN_Channel2);
    </code>
*/
adc_sync_result_t ADC_GetSyncConversion(adc1_channel_t adc1Channel, adc2_channel_t adc2Channel);

/**
  @Summary
    Acquisition Delay for temperature sensor

  @Description
    This routine should be called when temperature sensor is used.
    
  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    None

  @Param
    None

  @Example
    <code>
    uint16_t convertedValue;

    ADC_Initialize();    
    ADC_StartConversion();
    ADC_temperatureAcquisitionDelay();
    convertedValue = ADC_GetConversionResult();
    </code>
*/
void ADC_TemperatureAcquisitionDelay(void);

/**
  @Summary
    Allows to enable double conversion

  @Description
    This routine is used to enable double conversion on the same channel.
	Converted result will be stored in two different 10bit result register.    

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    None

  @Param
    None

  @Example
    <code>
    adc_sync_result_t convertedValues;

    ADC_Initialize();

    ADC1_EnableDoubleSampling();
    </code>
*/
void ADC1_EnableDoubleSampling(void);

/**
  @Summary
    Allows to enable double conversion

  @Description
    This routine is used to enable double conversion on the same channel.
	Converted result will be stored in two different 10bit result register.    

  @Preconditions
    ADC_Initialize() function should have been called before calling this function.

  @Returns
    None

  @Param
    None

  @Example
    <code>
    adc_sync_result_t convertedValues;

    ADC_Initialize();

    ADC2_EnableDoubleSampling();
    </code>
*/
void ADC2_EnableDoubleSampling(void);

/**
  @Summary
    Returns the ADC double conversion result
    
  @Description
    This routine is used to get the analog to digital converted values.

  @Preconditions
    ADC1_EnableDoubleSampling() function should have been called before calling this function.

  @Returns
    Returns the converted values.

  @Param
    None

  @Example
    <code>
    adc1_sync_double_result_t convertedValues;

    ADC_Initialize();
    ADC1_EnableDoubleSampling();

    convertedValues = ADC1_GetDoubleConversionResult();
    </code>
*/
adc1_sync_double_result_t ADC1_GetDoubleConversionResult(void);

/**
  @Summary
    Returns the ADC double conversion result
    
  @Description
    This routine is used to get the analog to digital converted values.

  @Preconditions
    ADC2_EnableDoubleSampling() function should have been called before calling this function.

  @Returns
    Returns the converted values.

  @Param
    None

  @Example
    <code>
    adc2_sync_double_result_t convertedValues;

    ADC_Initialize();
    ADC2_EnableDoubleSampling();

    convertedValues = ADC2_GetDoubleConversionResult();
    </code>
*/
adc2_sync_double_result_t ADC2_GetDoubleConversionResult(void);

/**
  @Summary
    Returns the ADC conversion Stage
    
  @Description
    This routine is used to get status of ADC process.
	(like Conversion or acquisition or precharge Stage)

  @Preconditions
    ADC1_StartConversion(AN1_Channel) function should have been called before calling this function.

  @Returns
    Returns the converted values.

  @Param
    None

  @Example
    <code>
    uint8_t conversionStage;

    ADC_Initialize();
    ADC1_StartConversion(AN1_Channel);

    conversionStage = ADC1_GetStageStatus();
    </code>
*/
uint8_t ADC1_GetStageStatus(void);

/**
  @Summary
    Returns the ADC conversion Stage
    
  @Description
    This routine is used to get status of ADC process.
	(like Conversion or acquisition or precharge Stage)

  @Preconditions
    ADC2_StartConversion(AN1_Channel) function should have been called before calling this function.

  @Returns
    Returns the converted values.

  @Param
    None

  @Example
    <code>
    uint8_t conversionStage;

    ADC_Initialize();
    ADC2_StartConversion(AN1_Channel);

    conversionStage = ADC2_GetStageStatus();
    </code>
*/
uint8_t ADC2_GetStageStatus(void);

/**
  @Summary
    Returns the ADC conversion Status
    
  @Description
    This routine is used to get status of ADC conversion.
	
  @Preconditions
    ADC1_StartConversion(AN1_Channel) function should have been called before calling this function.

  @Returns
    Returns the status.

  @Param
    None

  @Example
    <code>
    uint8_t conversionStatus;

    ADC_Initialize();
    ADC1_StartConversion(AN1_Channel);

    conversionStatus = ADC1_GetConversionStatus();
    </code>
*/
uint8_t ADC1_GetConversionStatus(void);

/**
  @Summary
    Returns the ADC conversion Status
    
  @Description
    This routine is used to get status of ADC conversion.
	
  @Preconditions
    ADC2_StartConversion(AN1_Channel) function should have been called before calling this function.

  @Returns
    Returns the status.

  @Param
    None

  @Example
    <code>
    uint8_t conversionStatus;

    ADC_Initialize();
    ADC2_StartConversion(AN1_Channel);

    conversionStatus = ADC2_GetConversionStatus();
    </code>
*/
uint8_t ADC2_GetConversionStatus(void);

/**
  @Summary
    Loads the Precharge register by the 8 bit value sent as argument.

  @Description
    Set the desired precharge time to charge.

  @Preconditions
    None.

  @Returns
    None

  @Param
    8 bit value to be set in the precharge register.

  @Example
    <code>
	uint8_t prechargeTime = 98;
	ADC1_SetPrechargeTime(prechargeTime);
    </code>
*/
void ADC1_SetPrechargeTime(uint8_t);

/**
  @Summary
    Loads the Precharge register by the 8 bit value sent as argument.

  @Description
    Set the desired precharge time to charge.

  @Preconditions
    None.

  @Returns
    None

  @Param
    8 bit value to be set in the precharge register.

  @Example
    <code>
	uint8_t prechargeTime = 98;
	ADC2_SetPrechargeTime(prechargeTime);
    </code>
*/
void ADC2_SetPrechargeTime(uint8_t);

/**
  @Summary
    Loads the Acquisition time by the 8 bit value sent as argument.

  @Description
    Set the desired Acquisition time.

  @Preconditions
    None.

  @Returns
    None

  @Param
    8 bit value to be set in the acquisition register.

  @Example
    <code>
	uint8_t acquisitionValue = 98;
	{moduleNameUpperCase}1_SetAcquisitionTime(acquisitionValue);
    </code>
*/
void ADC1_SetAcquisitionTime(uint8_t);

/**
  @Summary
    Loads the Acquisition time by the 8 bit value sent as argument.

  @Description
    Set the desired Acquisition time.

  @Preconditions
    None.

  @Returns
    None

  @Param
    8 bit value to be set in the acquisition register.

  @Example
    <code>
	uint8_t acquisitionValue = 98;
	{moduleNameUpperCase}2_SetAcquisitionTime(acquisitionValue);
    </code>
*/
void ADC2_SetAcquisitionTime(uint8_t);

#ifdef __cplusplus  // Provide C++ Compatibility

    }

#endif

#endif	//ADC_H
/**
 End of File
*/

